import type { MetadataRoute } from 'next';

const BASE_URL = 'https://quicktools-alpha.vercel.app';

export default function sitemap(): MetadataRoute.Sitemap {
  const tools = [
    { slug: 'word-counter', priority: 0.9 },
    { slug: 'lorem-ipsum-generator', priority: 0.8 },
    { slug: 'json-formatter', priority: 0.9 },
    { slug: 'case-converter', priority: 0.8 },
    { slug: 'password-generator', priority: 0.9 },
    { slug: 'base64-encoder-decoder', priority: 0.8 },
    { slug: 'url-encoder-decoder', priority: 0.8 },
    { slug: 'color-picker-converter', priority: 0.7 },
  ];

  return [
    {
      url: BASE_URL,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 1,
    },
    ...tools.map((t) => ({
      url: `${BASE_URL}/?tool=${t.slug}`,
      lastModified: new Date(),
      changeFrequency: 'monthly',
      priority: t.priority,
    })),
  ];
}